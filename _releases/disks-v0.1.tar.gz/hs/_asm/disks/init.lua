local module = require("hs._asm.disks.internal")
return module
